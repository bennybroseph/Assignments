from calctime import *

def main():
	PrintFromSeconds(60)
	PrintFromSeconds(3600)
	PrintFromSeconds(86400)
	PrintFromSeconds(2345234)
	
main()