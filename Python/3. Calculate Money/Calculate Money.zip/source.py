from calcmoney import *

def main():
	PrintFromPennies(25)
	PrintFromPennies(10)
	PrintFromPennies(5)
	PrintFromPennies(100)
	PrintFromPennies(249)
	
main()