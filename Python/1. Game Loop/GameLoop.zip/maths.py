import graphics
from graphics import *

def add(a, b):
    AplusB = Point(a.getX() + b.getX(), a.getY() + b.getY())
    return AplusB

