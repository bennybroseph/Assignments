#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <iostream>

namespace Graphics
{
	int Init();

	void New(char*);
	void End();

	void Quit();
}

#endif //GRAPHICS_H
